﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using WpfApp1.Repository;

namespace WpfApp1.View
{
    /// <summary>
    /// Логика взаимодействия для MainEmpty.xaml
    /// </summary>
    public partial class MainEmpty : Page
    {
        // Экземпляр класса-валидации
        private readonly Frame _frame;
        private readonly InputValidator _inputValidator = new InputValidator();

        public MainEmpty(Frame frame) 
        {
            InitializeComponent();
            _frame = frame;
        }

        // Регистрация нового пользователя
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            // Проверка заполнения полей
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Проверка длины пароля
            if (!_inputValidator.IsValidPassword(password))
            {
                MessageBox.Show("Минимальная длина пароля составляет 6 символов.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Warning);
                return;
            }

            // Выполняем попытку регистрации
            if (UserRepository.RegisterUser(username, password))
            {
                MessageBox.Show("Регистрация успешна!");
            }
            else
            {
                MessageBox.Show("Логин уже занят.");
            }
        }

        // Авторизация пользователя
        private void LoginButton_Click(object sender, RoutedEventArgs e)
        {
            string username = UsernameTextBox.Text.Trim();
            string password = PasswordBox.Password;

            // Проверка заполнения полей
            if (string.IsNullOrWhiteSpace(username) || string.IsNullOrWhiteSpace(password))
            {
                MessageBox.Show("Заполните все обязательные поля.", "Ошибка", MessageBoxButton.OK, MessageBoxImage.Error);
                return;
            }

            // Логика авторизации
            if (UserRepository.AuthenticateUser(username, password))
            {
                MessageBox.Show("Авторизация успешна!");
            }
            else
            {
                MessageBox.Show("Неверный логин или пароль.");
            }
        }

        // Дополнительный метод для отслеживания изменений текста
        private void UsernameTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            // Здесь можно добавить дополнительную обработку
        }

        private void Button_Click_1(object sender, RoutedEventArgs e)
        {
            _frame.Navigate(new MainWindow(_frame));
        }
    }

    // Вспомогательный класс для проверки входных данных
    public class InputValidator
    {
        // Проверка формата Email
        public bool IsValidEmail(string email)
        {
            return Regex.IsMatch(email, @"^[^@]+@[^.]+\..+$");
        }

        // Проверка минимальной длины пароля
        public bool IsValidPassword(string password)
        {
            return password.Length >= 6;
        }

        // Проверка минимального количества символов в имени
        public bool IsValidName(string name)
        {
            return name.Length >= 3;
        }
    }
}
