﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Markup;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApp1.View
{
    /// <summary>
    /// Логика взаимодействия для Main.xaml
    /// </summary>
    
    public partial class Main : Page
    {
        private readonly Frame _frame;

        public Main()
        {
            InitializeComponent();
            
        }

        public Main(Frame frame) : this()
        {
            _frame = frame;
        }

        private void CheckBox_Checked_1(object sender, RoutedEventArgs e)
        {
            TextBlock1.Text = Xlam.description;
        }

        private void ItemSource_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void CheckBox_Click(object sender, RoutedEventArgs e)
        {

        }

        private void CheckBox_Checked_2(object sender, RoutedEventArgs e)
        {
            TextBlock1.Text = "Почитать книгу";
        }

        private void CheckBox_Checked_3(object sender, RoutedEventArgs e)
        {
            TextBlock1.Text = "Поесть";
        }

        private void CheckBox_Checked_4(object sender, RoutedEventArgs e)
        {
            TextBlock1.Text = "Проверить";
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {

        }

        private void task1_Loaded(object sender, RoutedEventArgs e)
        {
            task1.Content = Xlam.task;
        }
    }
}
