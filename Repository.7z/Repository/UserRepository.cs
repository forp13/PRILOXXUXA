﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WpfApp1.Repository
{
    public class User
    {
        public string Username { get; set; }
        public string Password { get; set; }
    }

    internal class UserRepository
    {
        private static List<User> registeredUsers = new List<User>();

        // Метод для регистрации пользователей
        public static bool RegisterUser(string username, string password)
        {
            // Проверка на уникальность логина
            if (registeredUsers.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase)))
            {
                return false; // Логин уже занят
            }

            // Добавление нового пользователя
            registeredUsers.Add(new User { Username = username, Password = password });
            return true; // Регистрация успешна
        }

        // Метод для авторизации пользователей
        public static bool AuthenticateUser(string username, string password)
        {
            // Поиск пользователя по логину и паролю
            return registeredUsers.Any(u => u.Username.Equals(username, StringComparison.OrdinalIgnoreCase) && u.Password == password);
        }
    }
}
